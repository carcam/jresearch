// UK lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
	template_biblio : 'Generar bibliografía en base a los registros citados',
	template_citep : 'Citar una publicación. Los autores no son el sujeto de la oración',
	template_cite : 'Citar una publicación. Los autores son el sujeto de la oración',
	template_citeyear: 'Citar el año de una publicación',
	template_nocite: 'La publicación es citada, pero no se inserta ningún texto'	
	
});
