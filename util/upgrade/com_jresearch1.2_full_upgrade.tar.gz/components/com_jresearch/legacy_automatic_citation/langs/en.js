// UK lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
	template_biblio : 'Generate bibliography section based on cited records',
	template_citep : 'Cite a publication. Authors are not subject in the sentence',
	template_cite : 'Cite a publication. Authors are subject in the sentence',
	template_citeyear: 'Cite the year of a publication',
	template_nocite: 'Cite a publication, but do not insert anything'	
	
});
