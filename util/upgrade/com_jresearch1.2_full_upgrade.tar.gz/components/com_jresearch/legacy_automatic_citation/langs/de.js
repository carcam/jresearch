// UK lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
	template_biblio : 'Erstellt einen Bibliografie-Abschnitt entsprechend der zitierten Datens�tze',
	template_citep : 'Publikation zitieren. Autoren nicht als Betreff im Satz verwenden',
	template_cite : 'Publikation zitieren. Autoren als Betreff im Satz verwenden',
	template_citeyear: 'Jahr einer Publikation zitieren',
	template_nocite: 'Publikation zitieren aber nichts einf�gen.'

});
